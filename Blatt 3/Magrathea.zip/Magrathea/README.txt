Geofiles
  All simulation parameters are listed and the geometry is encoded with a character map using following characters:
  ' '     Fluid (Color: white, 0xFFFFFF)
  '#'     Wall/Obstacle/NoSlip (Color: black, 0x000000)
  'I'     General Inflowboarder (Color: magenta 0xFF00FF)
  'H'     Horizontal Inflowboarder (fluid flows in direction of Ui and Vi and is not determined here) (Color: yellow, 0xFFFF00)
  'V'     Vertical Inflowboarder (fluid flows in direction of Ui and Vi and is not determined here) (Color: red, 0xFF0000)
  'O'     Outflow (Color: blue, 0x0000FF)
  '|'     Vertical Slip-boundary (pressure is determined by Pi) (Color: green, 0x00FF00)
  '-'     Horizontal Slip-boundary (pressure is determined by Pi) (Color: cyan, 0x00FFFF)

  See EXAMPLE.geo and EXAMPLE.tga
